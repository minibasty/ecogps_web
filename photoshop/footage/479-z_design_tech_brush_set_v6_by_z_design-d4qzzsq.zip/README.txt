Thank you for downloading z-design tech brush set v6-CIRCULAR!


To install:

	1. Find your photoshop brushes folder (Usually your Adobe folder > Presets > Brushes)
	2. Place v6_circular.abr into your brushes folder


------------------------------------------------------------------------------


To use:

	1. Load Photoshop
	2. Go to Edit > Preset manager (Make sure brushes are displayed)
	3. Click "Load"
	4. Load the v6_circular.abr file
	5. Brushes should be loaded and ready for use.


------------------------------------------------------------------------------


For more tech resources:

	http://zanimation.com

	and

	http://z-design.deviantart.com


------------------------------------------------------------------------------


Please be sure to give credit to the original creator of the brushes(z-design) when you can.
Thank you!


------------------------------------------------------------------------------


Questions or concerns? Email zane@zanimation.com